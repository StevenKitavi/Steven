CREATE  ---MAKE NEW
RETRIEVE --GET --LIST /SEARCH
UPDATE --PUT /PATCH EDIT
DELETE --DELETE -delete
 

LIST/SEARCH



to handle all these we need views 

three require permissions execpt the retrieve
modifiable thingies for a blog higly intrractive employs crud intesively